#Intro Level Ruby Exercises#

Everyone's gotta start somewhere, right? These modules are for absolute beginners. If you don't know anything about Ruby or maybe even programming in general, start reading here.
