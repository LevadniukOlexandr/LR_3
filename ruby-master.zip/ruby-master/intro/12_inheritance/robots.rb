class Robot
  # Your code goes here
end

class Ultron < Robot
  # Your code goes here
end

class MegaMan < Robot
  # Your code goes here
end

class Glados < Robot
  # Your code goes here
end
