# Print out all the Fibonacci numbers from 1 to 10 in order

# Your code goes here

