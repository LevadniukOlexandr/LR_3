require "date"

class Phone
  # Your code goes here
end

phones = [
  {
    :brand              => "Apple", 
    :model              => "iPhone 1st gen", 
    :operating_system   => "iPhone OS 1.0", 
    :release_date       => Date.new(2007, 6, 29)
  },
  {
    :brand              => "Google", 
    :model              => "Nexus One", 
    :operating_system   => "Android 2.1 Eclair", 
    :release_date       => Date.new(2010, 1, 5)
  },
  {
    :brand              => "Samsung", 
    :model              => "Galaxy S", 
    :operating_system   => "Android 2.3.6 Gingerbread", 
    :release_date       => Date.new(2010, 6, 4)
  }
]

new_phones = []

# Your code goes here
