module WingChunMixin
  # Your code goes here
end

module BoxingMixin
  # Your code goes here
end

module FencingMixin
  # Your code goes here
end

module JeetKuneDoMixin
  # Your code goes here
end
