# Ages of family members
mom = 48
dad = 51
john = 18
mary = 16

# Your code goes here

