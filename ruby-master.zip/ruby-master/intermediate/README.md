Intermediate level Ruby exercises
====
